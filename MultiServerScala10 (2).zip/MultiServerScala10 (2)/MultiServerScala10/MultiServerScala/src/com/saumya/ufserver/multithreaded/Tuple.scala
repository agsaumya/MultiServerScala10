/**
 *
 */
package com.saumya.ufserver.multithreaded


import java.util.ArrayList
import java.util.List;


/**
 * @author Saumya
 *
 */

	class Tuple {
	//var tupleElements : List[TupleElement] = _
	
	//this{
		var tupleElements = new ArrayList[TupleElement]();
	//}
	
	def addTupleElement(tupleElement : TupleElement ) : Unit = {
		this.tupleElements.add(tupleElement);
	}
	
	def getTupleElement() : List[TupleElement] = {
		return this.tupleElements;
	}
	def matchTuple(tuple : Tuple) : Boolean = {
		var size : Int = 0;
		size = tupleElements.size()
		if(size != tuple.getTupleElement().size())
			return false;
		var elementsToMatch : List[TupleElement] = tuple.getTupleElement();
		var i = 0;
		for(i <- 0 until size){
		  var boolFlag: Boolean = tupleElements.get(i).eleMatch(elementsToMatch.get(i))
		  if(boolFlag ==false)
		    return false
			//if(! tupleElements.get(i).eleMatch(elementsToMatch.get(i)))
				//return false;
		}
		return true;
	}
}
