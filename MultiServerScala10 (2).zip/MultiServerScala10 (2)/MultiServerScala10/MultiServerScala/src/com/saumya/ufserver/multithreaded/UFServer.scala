/**
 *
 */
package com.saumya.ufserver.multithreaded


import java._
import java.io._
import scala.actors._
import scala.actors.remote._
import scala.actors.remote.RemoteActor._
import Actor._


/**
 * @author Saumya
 *
 */

class UFServer ( host:String, port:Int){
var host1:String = host;
var port1:Int=port;

def getHost() :String= {
return this.host1;
}

def getPort():Int = {
return this.port1;
}
}