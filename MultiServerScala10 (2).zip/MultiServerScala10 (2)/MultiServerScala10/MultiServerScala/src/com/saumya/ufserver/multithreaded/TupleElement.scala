/**
 *
 */
package com.saumya.ufserver.multithreaded
import java.lang._ 

/**
 * @author Saumya
 *
 */

class TupleElement (s : String, value1 : String){
  
	var eleType : String = s
  
	//var type:String = null  renamed to eleType
	
	var value : String = value1

	/*def TupleElement(s : String,value : String): Unit = {
		this.eleType = s;
		this.value = value;
	}*/

	def getType() : String = {
		return this.eleType;
	}

	def getValue() : String = {
		return this.value;
	}

	def eleMatch(element : TupleElement) : Boolean = {
		/*
		if(this.type.equalsIgnoreCase(element.getType())
				|| this.value.equalsIgnoreCase(element.getValue()))
			return true;
		return false;*/

		if(this.eleType.equalsIgnoreCase(element.getType()))
		{
			if(this.value.equalsIgnoreCase(element.getValue()))//match tuple values
				return true;
			else if(element.getValue().equalsIgnoreCase(this.eleType))
				return true;
			else
				return false;
		}
		else
			return false;
	}//end of method
}
