/**
 *
 */
package com.saumya.ufserver.multithreaded

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.UnknownHostException
import java.util.ArrayList
import java.util.List
import scala.collection.JavaConversions._
import java.lang.Float
import java.io.FileReader
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.FileWriter
import java.io.FileOutputStream
import java.io.FileInputStream
import java.io.File;
//import java.io.BufferedReader


/**
 * @author Saumya
 *
 */

class Users (user : String, pass : String)
{
	var username : String = user
	var password : String = pass
			// var userType : Boolean = usertype


	def getUsername() : String = {
			return this.username;
			}

	def getPassword() : String = {
					return this.password;
			}
	def setUsername(usrname : String) : Unit = {
			this.username = usrname;
			}

	def setPassword(passwrd : String) : Unit = {
			this.password = passwrd;
			}

}


class UFServiceStartPoint {

  var authenticatedUsers : List[Users] = _
  
		
  
	var otherDistributedServers : List[UFServer] = _   //clusterhead list
	private var serverSocket : ServerSocket = null 
	private var tuples : List[Tuple] = _
	var closeFlag : Boolean = true
	
	val defaultServerUserName = "server"
	val defaultServerPassword = "uf"
	
	val fileName = "datastore.txt"
	val sharedKey = "QWERTYUIOPASDFGHJKLZXCVBNM";
	  
	var port: Int = _
	
	//var  Parent: UFServer = new UFServer(null,0)
	//var parentIP : String= _;
	//var parentPort : Int = _
	var childList : List[UFServer] = _
	
	
	
	//var fop : FileOutputStream = null;
	var file : File = _;
	var fw : FileWriter = _;
	var fr : FileReader = _;
	var fileWriter : BufferedWriter = _;
	var fileReader : BufferedReader = _;
	
	var isClusterHead :String = _;
	var parentServer : UFServer = new UFServer(null,0)
	var requestfromserver = new UFServer(null,0)	
	
	//var outputStream = new FileOutputStream (fileName);
	//var inputStream = new FileInputStream (fileName);
	
			//val fileReader = new BufferedReader(new FileReader(fileName));
			//val fileWriter = new BufferedWriter(new FileWriter(fileName));
	
	//eStartPoint(){
		
	var admin : Users = _
	authenticatedUsers = new ArrayList[Users]();
	authenticatedUsers.add(new Users(defaultServerUserName,defaultServerPassword));
	
		otherDistributedServers = new ArrayList[UFServer]();
		childList = new ArrayList[UFServer]();
		//otherDistributedServers.add(new UFServer("10.136.83.134", 9000));
		//otherDistributedServers.add(new UFServer("localhost", 10000));
		tuples = new ArrayList[Tuple]();
		
		//BufferedReader reader = new BufferedReader(new FileReader(filename));
	
	
		def startService() : Unit =  {
				
		  System.out.println("Enter the Admin Username: ");
			var reader  = new DataInputStream(System.in)
			var adminUserName  = reader.readLine()
			System.out.println("Enter the Admin password: ");
				var adminPassword  = reader.readLine()
		  
		  
		  		admin = new Users (adminUserName, adminPassword)
				
				authenticatedUsers.add(admin);
				
				println(authenticatedUsers.size());
				
				
				file = new File(fileName);
 
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
						  
			
			fw = new FileWriter(file.getAbsoluteFile(), true);
			fr = new FileReader(file.getAbsoluteFile());
			fileWriter = new BufferedWriter(fw);
			fileReader = new BufferedReader(fr);
			
			var fileCurrentLine = fileReader.readLine();
			//println(fileCurrentLine);
			
			
			//initializing the datastore data structure with the data in the file
			while (fileCurrentLine != null) {

						//println(fileCurrentLine);
				insert(fileCurrentLine,false);
				fileCurrentLine = fileReader.readLine()
				
			}
		
				
		fileReader.close();
		fr = new FileReader(file.getAbsoluteFile());
		fileReader = new BufferedReader(fr);
		
					System.out.println("Enter the port on which server will listen for client requests");
					var portNum = Integer.parseInt(reader.readLine());

					//int portNum = Integer.parseInt(reader.readLine());
					port = portNum;
		println("Are you a cluster head? ");
	
		isClusterHead = reader.readLine()
		
		
		 var parentServerWriter : DataOutputStream = null;
		 var parentServerReader : DataInputStream = null;
		
		
		
		if(!isClusterHead.equalsIgnoreCase("true"))
		{
		  println("Enter parent's ip and port");
		  
		  parentServer.host1=reader.readLine();
		  parentServer.port1  =Integer.parseInt( reader.readLine());
		 // var parentServer = new UFServer (reader.readLine(), Integer.parseInt( reader.readLine()));
		  	  
		  var parentSocket = new Socket(parentServer.host1, parentServer.port1);
		  parentServerReader = new DataInputStream(parentSocket.getInputStream());
		  parentServerWriter = new DataOutputStream(parentSocket.getOutputStream());
		  parentServerWriter.writeUTF(defaultServerUserName + "," + defaultServerPassword);
		  var parentServerResponse : String = parentServerReader.readUTF();
		  //println("received parentServerResponse tempValue: " + parentServerResponse)
		  
		  if(Integer.parseInt(parentServerResponse) == 1)
		  {
		     var newClusterHeadInfo : String = parentServerReader.readUTF();
		     while(!newClusterHeadInfo.equalsIgnoreCase("end"))
		     {
		       addDistributedServerInfo(newClusterHeadInfo);
		       newClusterHeadInfo = parentServerReader.readUTF();
		     }
		       
		  }
		  
		  parentServerWriter.writeUTF(encrypt("child<>"+port ,sharedKey));
		  		  
		   parentServerResponse = parentServerReader.readUTF();
		  //println("received parentServerResponse: " + parentServerResponse)
		  
		  parentServerWriter.writeUTF(encrypt("exit<>",sharedKey));
		  //println("exit command gone?");
		  parentSocket.close();		  
		  
		}
		else
		{
		  addDistributedServerInfo(getLocalHostAddressServerInfo() + "," + port);
		}
		
		
/*				try
				{
			
					
				}
				catch 
				{
				  case e : Exception => println("Exception occurred trying to open file : " + fileName);
				  e.printStackTrace();
				  throw e;				
				}
*/1
				//DataInputStream reader = new DataInputStream(System.in);
				try{
					//@SuppressWarnings("deprecation")


					serverSocket = new ServerSocket(port);
					while(true){

						var clientSocket : Socket = serverSocket.accept() //listening to all the connections
						
						
						//server connection start code
							

					System.out.println("Connected to client - " + clientSocket.getInetAddress().getCanonicalHostName() + "/" + clientSocket.getPort());
						//requestfromserver.host1 = clientSocket.getInetAddress().getCanonicalHostName()
						//requestfromserver.port1=clientSocket.getPort();
						
						//temp code for authentication purpose
						
					var tempClientreader = new DataInputStream(clientSocket.getInputStream());
					var tempClientwriter = new DataOutputStream(clientSocket.getOutputStream());
						
						var readrequest : String = tempClientreader.readUTF();
						
						System.out.println("Request from client-" + clientSocket.getInetAddress().getCanonicalHostName() + "/" + 
						clientSocket.getPort() + ", request -" + readrequest);
						var requestParts = readrequest.split(",");
					
					var tempValue = 0 ; // 0 = not found, 1 = found 
				
					var it = authenticatedUsers.iterator();
					while(it.hasNext())
					{
					  var listUser = it.next()
					  if(listUser.getUsername.equalsIgnoreCase(requestParts(0)) && listUser.getPassword.equalsIgnoreCase(requestParts(1)))
					      tempValue = 1;
					}
				
				//println(tempValue);
						if(tempValue == 1)
						{
						  
						  //sending serverinfo
						  tempClientwriter.writeUTF("" + tempValue)
						  
						  //send chlist info
						   for( otherServer <- otherDistributedServers){                                
                                       tempClientwriter.writeUTF( otherServer.getHost() + "," + otherServer.getPort());                                        
                               }
                               tempClientwriter.writeUTF("end");
                              // tempClientwriter.flush();
						  //sending serverinfo code ends
						  
						  //client authenticated
					var clientRequest = new Thread(new ClientHandler(clientSocket));

					//Thread clientRequest = new Thread(new ClientHandler(clientSocket));
					clientRequest.start();
					
					
					
	  				if(!closeFlag) 
	  				  return;
						}
						else
						{
						  tempClientwriter.writeUTF("" + tempValue)
						}
						
						
						  	
						  
						
					}
				}  catch {
				case e : IOException => println("Error starting up the server");
				e.printStackTrace();
				throw e;
				case ex : NumberFormatException => println("Port number entered is not an integer, not able to start the server");
				throw ex
				}
		}
	
	def addDistributedServerInfo(serverInfo : String)  : Unit = {
	  
	  //var serverParts : Array[String] = serverInfo.split(",")
	  var serverParts = serverInfo.split(",")
	  
	//	String serverParts[] = serverInfo.split(",")	  
	  var matched : Boolean = true 
		
		
		//for checking for local server info	  
		var localHostName : String = getLocalHostNameServerInfo();
		var localHostAddress : String = getLocalHostAddressServerInfo();
				
		var portNum = port
		
		//println("Hi-3" + localHostName + ", " + localHostAddress + ", " + portNum);
		//println("Arraylist size" + otherDistributedServers.size());
		
		//var ufserver : UFServer = 
		// for loop execution with a collection
		//for( ufserver <- otherDistributedServers)
		  
		  
		  
		  //for( UFServer ufserver : otherDistributedServers)
		for( ufserver <- otherDistributedServers)
		  
		  
			{
			println(" otherServer:  " + ufserver.getHost() + "," + ufserver.getPort());
			if(ufserver.getHost().equalsIgnoreCase(serverParts(0)) && ufserver.getPort() == Integer.parseInt(serverParts(1)) )
				matched = false;
			}
		
		
		/*if(serverParts(0).equalsIgnoreCase(localHostName) && portNum == Integer.parseInt(serverParts(1)))
			return;
		else if(serverParts(0).equalsIgnoreCase(localHostAddress) && portNum == Integer.parseInt(serverParts(1)))
			return;
		*/
		if(matched)
		//  		otherDistributedServers.add(new UFServer(serverParts(0), Integer.parseInt(serverParts(1)))); //new serverinfo added here
		{
		  var newPortNum = Integer.parseInt(serverParts(1))
		  var newServerHost = serverParts(0)
		  //var newUF = new UFServer (newServerHost,newPortNum)
		  otherDistributedServers.add(new UFServer(serverParts(0), newPortNum)); //new serverinfo added here
		  		  
		}
		
		//println("Arraylist size after insertion" + otherDistributedServers.size());
	}
	
	
	def getLocalHostNameServerInfo() : String = 
	{
	  
		  var ownIP : InetAddress=InetAddress.getLocalHost();
		  return ownIP.getHostName();
	}
	def getLocalHostAddressServerInfo() : String =
	{
		  var ownIP : InetAddress=InetAddress.getLocalHost();
		  return ownIP.getHostAddress();
	}
	
	def printAllTuples() : String= {
		for(tuple <- tuples)
			println(generateStringFromTuple(tuple));
		return "Successfully printed all the tuples at server";
	}
	
	
	
	def createnewuser(parms : String) : String =
	{
	  
	  var authenticationParms = parms.split(",")
	  
	  if(admin.getUsername.equalsIgnoreCase(authenticationParms(0)) && admin.getPassword.equalsIgnoreCase(authenticationParms(1)))
	  {
	    authenticatedUsers.add(new Users(authenticationParms(2),authenticationParms(3)))
	    
	    //println("userlist size: " + authenticatedUsers.size());
	    return "new user created successfully"
	  }
	  else
	    return "new user not created"  
	  
	}
	
	
	
	def deleteuser(parms : String) : String =
		{

			var authenticationParms = parms.split(",")
			var username = authenticationParms(2)
			
			var tempValue : Int = 0
			if(admin.getUsername.equalsIgnoreCase(authenticationParms(0)) && admin.getPassword.equalsIgnoreCase(authenticationParms(1)))
			{
				//authenticatedUsers.remove(username)
			  
					
					var it = authenticatedUsers.iterator();
					while(it.hasNext() && tempValue == 0)
					{
						var listUser = it.next()
						if(listUser.getUsername.equalsIgnoreCase(username))
								{
									authenticatedUsers.remove(listUser)
									tempValue = 1;
									
								}
						
					}
			}
		if(tempValue == 1)					  
					{	
					  //println("userlist size: " + authenticatedUsers.size());
						return "username: " + username + " deleted successfully"
					}
			
			
			else
				return "username: " + username + " NOT deleted successfully"  

		}
	
	def changepassword(parms : String) : String =
	{
	  
	  var authenticationParms = parms.split(",")
	  var newPassword = authenticationParms(2)
	  
	  var tempValue = 0

	  var it = authenticatedUsers.iterator();
			while(it.hasNext() && tempValue == 0)
			{
				var listUser = it.next()
				if(listUser.getUsername.equalsIgnoreCase(authenticationParms(0)) && listUser.getPassword.equalsIgnoreCase(authenticationParms(1)))
						{
							listUser.setPassword(newPassword)
							tempValue = 1;
						}
			}
	  
	  if(tempValue == 1)
	  {    
	    //println("userlist size: " + authenticatedUsers.size());
	    return "password changed successfully"
	  }
	  else
	    return "invalid username/password combination"  
	  
	}
	
	
	
	/**
	 * All Client can access this method to insert tuple
	 * @param tuple
	 * @return message specifying success or failure
	 */
	def insert(tuple: String, flag: Boolean) : String={
		var message : String = null
		try{
			var tupleToInsert:Tuple = generateTupleForInsert(tuple);
			tuples.add(tupleToInsert);
			
			if(flag)
			{
				fileWriter.write(tuple);
				fileWriter.newLine()
				fileWriter.close();
				println(file);
				fw = new FileWriter(file.getAbsoluteFile(), true);
				fileWriter = new BufferedWriter(fw);
		}
					
			message = "Successfully entered the tuple: "+ tuple;
		} catch{
		  case ex : IllegalArgumentException => message = ex.getMessage();
		}
		return message;
	}
	
	def generateTupleForInsert(tuple : String) : Tuple ={
	  
	  var tupleElements = tuple.split(",");
		//String[] tupleElements = tuple.split(",");
	  
	  
		var tupleToInsert = new Tuple();
		for(tupleElement <- tupleElements){
			if(isInteger(tupleElement))
				tupleToInsert.addTupleElement( new TupleElement("int",tupleElement));
			else if(isFloat(tupleElement))
				tupleToInsert.addTupleElement( new TupleElement("float",tupleElement));
			else if(tupleElement.startsWith("'"))
				tupleToInsert.addTupleElement( new TupleElement("char",tupleElement));
			else if(tupleElement.startsWith("\""))
				tupleToInsert.addTupleElement( new TupleElement("string",tupleElement));
			else
				throw new IllegalArgumentException("Invalid Request, only int,float,char and string types are allowed");
		}
		return tupleToInsert;
	}
	
	def generateTupleForMatch(tuple : String) : Tuple ={
		var tupleElements = tuple.split(",");
		var tupleToInsert = new Tuple();
		
		for(tupleElement <- tupleElements){
			if("int".equalsIgnoreCase(tupleElement) || isInteger(tupleElement))
				tupleToInsert.addTupleElement( new TupleElement("int",tupleElement));
			else if("float".equalsIgnoreCase(tupleElement) || isFloat(tupleElement))
				tupleToInsert.addTupleElement( new TupleElement("float",tupleElement));
			else if("char".equalsIgnoreCase(tupleElement) || tupleElement.startsWith("'"))
				tupleToInsert.addTupleElement( new TupleElement("char",tupleElement));
			else if("string".equalsIgnoreCase(tupleElement) || tupleElement.startsWith("\""))
				tupleToInsert.addTupleElement( new TupleElement("string",tupleElement));
			else
				throw new IllegalArgumentException("Invalid Request, only int,float,char and string types are allowed");
		}
		
		return tupleToInsert;
		
	}
	
	def isInteger(value : String) : Boolean = {
		try{
			Integer.parseInt(value);
		}catch{
		  case ex : NumberFormatException =>	return false;
		}
		return true;
	}
	
	def isFloat(value : String) : Boolean ={
		try{
			Float.parseFloat(value);
		}catch{
		  case ex : NumberFormatException =>	return false;
		}
		return true;
	}
	
	def matchTup(tuple: String, requestfromserver : UFServer) : String = {
		//int index = 0;
		var message = "";
		var msg = "";
		var matchedIndexes = new Array[Int](tuple.size);
		//int[] matchedIndexes = new int[tuples.size()];
		try{
			var tupleToMatch = generateTupleForMatch(tuple);
			
		matchedIndexes = getIndexForMatch(tupleToMatch);
		} catch{
		  case ex: IllegalArgumentException => message = ex.getMessage();
		}
		//println("length : " + matchedIndexes.length);
		
		
		if(matchedIndexes.length != 0)
		{
			var i = 0	
			var breakFlag = true;
				//for(int i =0; i<matchedIndexes.length; i++)
			while (breakFlag)
			{
			 
			  	//System.out.println(" i, MI: " + i + "," + matchedIndexes(i));
					if(matchedIndexes(i) != -1)
						message += "\n" + generateStringFromTuple(tuples.get(matchedIndexes(i)));
					else
						//break;
					  breakFlag = false;
			  
			  i = i+1
			  if(i>=matchedIndexes.length)
			    	  breakFlag = false;
			    
			}
		}
		/*
		for(i <- 0 until (matchedIndexes.length && breakFlag!=false))
			{
				
				//System.out.println(" i, MI: " + i + "," + matchedIndexes(i));
				if(matchedIndexes(i) != -1)
					message += "\n" + generateStringFromTuple(tuples.get(matchedIndexes(i)));
				else
					//break;
				  breakFlag = false;
			}
				
		}*/
		msg = findOnOtherServers(tuple, false, requestfromserver)
		if(msg!=null)
		{
		  println("from other servers msg: " + msg);
		//message += findOnOtherServers(tuple, false);
			message +=  msg;
		}
		System.out.println("Message: " + message);
		
/*		if(message.equalsIgnoreCase(""))
		{//System.out.println("deelte msg");
			message += "NO MATCH";
		}
	*/		//index = getIndexForMatch(tupleToMatch);		
		//if(index != -1)
			//message = generateStringFromTuple(tuples.get(index));
		//else if((message = findOnOtherServers(tuple, false)) != null)
			//;
		//else
			
		return message;
	}
	
	def matchFromOtherServer(tuple: String) : String = {
		//int index = 0;
		var message = "";
		var msg = "";
		var matchedIndexes = new Array[Int](tuple.size);
		//int[] matchedIndexes = new int[tuples.size()];
		try{
			var tupleToMatch = generateTupleForMatch(tuple);
			
		matchedIndexes = getIndexForMatch(tupleToMatch);
		} catch{
		  case ex: IllegalArgumentException => message = ex.getMessage();
		}
		//println("length : " + matchedIndexes.length);
		
		
		if(matchedIndexes.length != 0)
		{
			var i = 0	
			var breakFlag = true;
				//for(int i =0; i<matchedIndexes.length; i++)
			while (breakFlag)
			{
			 
			  	//System.out.println(" i, MI: " + i + "," + matchedIndexes(i));
					if(matchedIndexes(i) != -1)
						message += "\n" + generateStringFromTuple(tuples.get(matchedIndexes(i)));
					else
						//break;
					  breakFlag = false;
			  
			  i = i+1
			  if(i>=matchedIndexes.length)
			    	  breakFlag = false;
			    
			}
		}
		/*
		for(i <- 0 until (matchedIndexes.length && breakFlag!=false))
			{
				
				//System.out.println(" i, MI: " + i + "," + matchedIndexes(i));
				if(matchedIndexes(i) != -1)
					message += "\n" + generateStringFromTuple(tuples.get(matchedIndexes(i)));
				else
					//break;
				  breakFlag = false;
			}
				
		}*/
		msg = findOnOtherServers(tuple, false, requestfromserver)
		if(msg!=null)
		{
		  println("from other servers msg: " + msg);
		//message += findOnOtherServers(tuple, false);
			message +=  msg;
		}
		System.out.println("Message: " + message);
		
/*		if(message.equalsIgnoreCase(""))
		{//System.out.println("deelte msg");
			message += "NO MATCH";
		}
	*/		//index = getIndexForMatch(tupleToMatch);		
		//if(index != -1)
			//message = generateStringFromTuple(tuples.get(index));
		//else if((message = findOnOtherServers(tuple, false)) != null)
			//;
		//else
			
		return message;
	}
	
	def delete(tuple : String, requestfromserver : UFServer) : String = {
	  this.synchronized { }
		var message = "";
		//String message = "";
		//int[] matchedIndexes = new int[tuples.size()];
		var matchedIndexes = new Array[Int](tuple.size);
		var matchLength = 0;
		var k=0;
		try{
			var tupleToMatch = generateTupleForMatch(tuple);
			matchedIndexes = getIndexForMatch(tupleToMatch);
			/*int index = getIndexForMatch(tupleToMatch);
			if(index != -1){
				message = generateStringFromTuple(tuples.get(index));
				tuples.remove(index);
			}*/
			matchLength = matchedIndexes.length;
				
			
		if(matchLength > 0)
		{
			var i = 0	
			var breakFlag = true;
				//for(int i =0; i<matchedIndexes.length; i++)
			while (breakFlag)
			{
			 
			  	//System.out.println("mo  i, MI: " + i + "," + matchedIndexes(i));
					if(matchedIndexes(i) != -1)
						{	message += "\n" + generateStringFromTuple(tuples.get(matchedIndexes(i)-k));
						tuples.remove(matchedIndexes(i)-k);
						k = k+1;
					}
					else
						//break;
					  breakFlag = false;
			  
			  i = i+1
			  if(i>=matchLength)
			    	  breakFlag = false;
			    
			}
		}
			
		
		//delete from file
		var deleteList = message.split("\n");
		var sCurrentLine : String = null
		var indexInList = 1;
		var newData = "";
		
		while(indexInList < deleteList.length)
		{
		  //println("outside here");
		  sCurrentLine = fileReader.readLine()
		  
		  //println("scurrentline: " + sCurrentLine + ", deleteList element:" + deleteList(indexInList) + "indexInList:" + indexInList);
		  while(sCurrentLine != deleteList(indexInList) )// && sCurrentLine!=null)
		  {
		   // println("inside here");
		     // println("scurrentline2: " + sCurrentLine + ", deleteList element2:" + deleteList(indexInList) + "indexInList:" + indexInList);
		    newData = newData + sCurrentLine + "\n";
		    sCurrentLine = fileReader.readLine()
		  }		  		  
		  
		  indexInList = indexInList + 1;
		}
		
		sCurrentLine = fileReader.readLine();
		
		while (sCurrentLine != null) {

				//System.out.println(sCurrentLine);
				newData = newData + sCurrentLine + "\n";
				sCurrentLine = fileReader.readLine()
				
			}
		//println("new data:" + newData);
		fileReader.close();
		fileWriter.close();
				
		//println("outside ");
		
			fw = new FileWriter(file.getAbsoluteFile());
			fr = new FileReader(file.getAbsoluteFile());
			fileWriter = new BufferedWriter(fw);
			fileReader = new BufferedReader(fr);
			fileWriter.write(newData);
				fileReader.close();
		fileWriter.close();
			
		
		//println("outside 2");
		
			fw = new FileWriter(file.getAbsoluteFile(), true);
			fr = new FileReader(file.getAbsoluteFile());
			fileWriter = new BufferedWriter(fw);
			fileReader = new BufferedReader(fr);
		
		//creating second file
		
		/*var copyFileName = "copydatastore.txt";
		var file2 = new File(copyFileName);
 
			// if file doesnt exists, then create it
			if (!file2.exists()) {
				file2.createNewFile();
			}
			
			
		var copyfw2 : FileWriter = new FileWriter(file2, true);
		var copyFileWriter = new BufferedWriter(copyfw2);
		
		var sCurrentLine : String = null
		
		var indexInList = 1;
		
		println("deleteList length" + deleteList.length);
		while(indexInList < deleteList.length)
		{
		  
		 // println("outside here");
		  sCurrentLine = fileReader.readLine()
		//  println("scurrentline: " + sCurrentLine + ", deleteList element:" + deleteList(indexInList));
		  while(sCurrentLine != deleteList(indexInList))
		  {
		 //   println("inside here");
		    copyFileWriter.write(sCurrentLine);
		    copyFileWriter.newLine()
		    sCurrentLine = fileReader.readLine()		    
		  }		  		  
		  
		  indexInList = indexInList + 1;
		}
		
		sCurrentLine = fileReader.readLine()
		while (sCurrentLine != null) {
          //sCurrentLine = fileReader.readLine();
				System.out.println(sCurrentLine);
				copyFileWriter.write(sCurrentLine);
				copyFileWriter.newLine()
				sCurrentLine = fileReader.readLine()
			}
		
		fileReader.close();
		fileWriter.close();
		file.delete();
		
		//println("outside ");
		
		copyFileWriter.close();
		
		var file3 = file2;
		file2.renameTo(new File(fileName));
		file = file2;
		file3.delete();
				 
			file2 = null;
			fw = new FileWriter(file.getAbsoluteFile(), true);
			fr = new FileReader(file.getAbsoluteFile());
			fileWriter = new BufferedWriter(fw);
			fileReader = new BufferedReader(fr);
		*/
		
		
		
		
		var temp1:String ="";
                       temp1 = findOnOtherServers(tuple,true,requestfromserver);
                       if(temp1!="")
                       message += temp1;
                       /*if(message == "")
                               message = "NO MATCH";
		*/
		
			/*if(findOnOtherServers(tuple, true)!=null)
			message += findOnOtherServers(tuple, true);
			
			
			if(message == "")
				message = "NO MATCH";
			*/
			/*
			else if((message = findOnOtherServers(tuple, true)) != null){
				
			} else
				message = "NO MATCH";*/
		} catch{
		  case ex: IllegalArgumentException => message = ex.getMessage();
		}
		return message;
	}
	
	def deleteFromOtherServer(tuple : String) : String ={
	  this.synchronized { }
		var message = "";
		//String message = "";
		//int[] matchedIndexes = new int[tuples.size()];
		var matchedIndexes = new Array[Int](tuple.size);
		var matchLength = 0;
		var k=0;
		try{
			var tupleToMatch = generateTupleForMatch(tuple);
			matchedIndexes = getIndexForMatch(tupleToMatch);
			/*int index = getIndexForMatch(tupleToMatch);
			if(index != -1){
				message = generateStringFromTuple(tuples.get(index));
				tuples.remove(index);
			}*/
			matchLength = matchedIndexes.length;
				
			
		if(matchLength > 0)
		{
			var i = 0	
			var breakFlag = true;
				//for(int i =0; i<matchedIndexes.length; i++)
			while (breakFlag)
			{
			 
			  //	System.out.println("mo  i, MI: " + i + "," + matchedIndexes(i));
					if(matchedIndexes(i) != -1)
						{	message += "\n" + generateStringFromTuple(tuples.get(matchedIndexes(i)-k));
						tuples.remove(matchedIndexes(i)-k);
						k = k+1;
					}
					else
						//break;
					  breakFlag = false;
			  
			  i = i+1
			  if(i>=matchLength)
			    	  breakFlag = false;
			    
			}
		}
			
		
		//delete from file
		var deleteList = message.split("\n");
		var sCurrentLine : String = null
		var indexInList = 1;
		var newData = "";
		
		while(indexInList < deleteList.length)
		{
		 // println("outside here");
		  sCurrentLine = fileReader.readLine()
		  
		//  println("scurrentline: " + sCurrentLine + ", deleteList element:" + deleteList(indexInList) + "indexInList:" + indexInList);
		  while(sCurrentLine != deleteList(indexInList) )// && sCurrentLine!=null)
		  {
		 //   println("inside here");
		   //   println("scurrentline2: " + sCurrentLine + ", deleteList element2:" + deleteList(indexInList) + "indexInList:" + indexInList);
		    newData = newData + sCurrentLine + "\n";
		    sCurrentLine = fileReader.readLine()
		  }		  		  
		  
		  indexInList = indexInList + 1;
		}
		
		sCurrentLine = fileReader.readLine();
		
		while (sCurrentLine != null) {

				System.out.println(sCurrentLine);
				newData = newData + sCurrentLine + "\n";
				sCurrentLine = fileReader.readLine()
				
			}
		println("new data:" + newData);
		fileReader.close();
		fileWriter.close();
				
		//println("outside ");
		
			fw = new FileWriter(file.getAbsoluteFile());
			fr = new FileReader(file.getAbsoluteFile());
			fileWriter = new BufferedWriter(fw);
			fileReader = new BufferedReader(fr);
			fileWriter.write(newData);
				fileReader.close();
		fileWriter.close();
			
		
		//println("outside 2");
		
			fw = new FileWriter(file.getAbsoluteFile(), true);
			fr = new FileReader(file.getAbsoluteFile());
			fileWriter = new BufferedWriter(fw);
			fileReader = new BufferedReader(fr);
		
		//creating second file
		
		/*var copyFileName = "copydatastore.txt";
		var file2 = new File(copyFileName);
 
			// if file doesnt exists, then create it
			if (!file2.exists()) {
				file2.createNewFile();
			}
			
			
		var copyfw2 : FileWriter = new FileWriter(file2, true);
		var copyFileWriter = new BufferedWriter(copyfw2);
		
		var sCurrentLine : String = null
		
		var indexInList = 1;
		
		println("deleteList length" + deleteList.length);
		while(indexInList < deleteList.length)
		{
		  
		//  println("outside here");
		  sCurrentLine = fileReader.readLine()
		//  println("scurrentline: " + sCurrentLine + ", deleteList element:" + deleteList(indexInList));
		  while(sCurrentLine != deleteList(indexInList))
		  {
		  //  println("inside here");
		    copyFileWriter.write(sCurrentLine);
		    copyFileWriter.newLine()
		    sCurrentLine = fileReader.readLine()		    
		  }		  		  
		  
		  indexInList = indexInList + 1;
		}
		
		sCurrentLine = fileReader.readLine()
		while (sCurrentLine != null) {
          //sCurrentLine = fileReader.readLine();
				System.out.println(sCurrentLine);
				copyFileWriter.write(sCurrentLine);
				copyFileWriter.newLine()
				sCurrentLine = fileReader.readLine()
			}
		
		fileReader.close();
		fileWriter.close();
		file.delete();
		
		//println("outside ");
		
		copyFileWriter.close();
		
		var file3 = file2;
		file2.renameTo(new File(fileName));
		file = file2;
		file3.delete();
				 
			file2 = null;
			fw = new FileWriter(file.getAbsoluteFile(), true);
			fr = new FileReader(file.getAbsoluteFile());
			fileWriter = new BufferedWriter(fw);
			fileReader = new BufferedReader(fr);
		*/
		
		
		
		
		var temp1:String ="";
                       temp1 = findOnOtherServers(tuple,true,requestfromserver);
                       if(temp1!="")
                       message += temp1;
                       /*if(message == "")
                               message = "NO MATCH";
		*/
		
			/*if(findOnOtherServers(tuple, true)!=null)
			message += findOnOtherServers(tuple, true);
			
			
			if(message == "")
				message = "NO MATCH";
			*/
			/*
			else if((message = findOnOtherServers(tuple, true)) != null){
				
			} else
				message = "NO MATCH";*/
		} catch{
		  case ex: IllegalArgumentException => message = ex.getMessage();
		}
		return message;
	}
	
	def findOnOtherServers(tuple : String,delete : Boolean, requestfromserver : UFServer) : String = {
		var message = "";
		var msg :String = null;	
		
		// will semd to children and parent
		
		if(isClusterHead.equalsIgnoreCase("true"))
		{
		//  println("inside isClusterHead : " + isClusterHead)
		for( otherServer <- otherDistributedServers){

		  		if( !(otherServer.getHost().equalsIgnoreCase(getLocalHostNameServerInfo()) && otherServer.getPort == port) && !(otherServer.getHost().equalsIgnoreCase(getLocalHostAddressServerInfo) && otherServer.getPort == port))
		  		{
		  		  
		  		  if(!(requestfromserver.getHost().equalsIgnoreCase(otherServer.getHost()) && (requestfromserver.getPort() == otherServer.getPort())))
		  {
		  		 // println("inside otherDis" )
		//else if(otherServer.getHost().equalsIgnoreCase(getLocalHostAddressServerInfo) && otherServer.getPort == port)
			//continue;

		  
		  msg = getInfoOnServer(otherServer, tuple, delete)
			if(msg !=null)
			//message += getInfoOnServer(otherServer, tuple, delete);
				message += msg;
		//	if( null != message)
		//		break;
		  }
		  		}
		}
		}

		else
		{
		  if(!(requestfromserver.getHost().equalsIgnoreCase(parentServer.getHost()) && (requestfromserver.getPort() == parentServer.getPort())))
		  {
		    println("inside parentlist for : "  + parentServer.getHost + ", " + parentServer.getPort)
		msg = getInfoOnServer(parentServer, tuple, delete)
			if(msg !=null)
			//message += getInfoOnServer(otherServer, tuple, delete);
				message += msg;
		  }
		
		}
		for( otherServer <- childList){
		  
		  //if(!(requestfromserver.host1==otherServer.host1 && requestfromserver.port1==otherServer.port1) )
		    if(!(requestfromserver.getHost().equalsIgnoreCase(otherServer.getHost()) && (requestfromserver.getPort() == otherServer.getPort())))
		 // if(false)  
		  {
		  //  println("inside childlist for : "  + requestfromserver.getHost() + ", " + requestfromserver.getPort())
		 //   println("otherserverinfo : "  + otherServer.getHost + ", " + otherServer.getPort)
			  msg = getInfoOnServer(otherServer, tuple, delete)
				if(msg !=null)
				//message += getInfoOnServer(otherServer, tuple, delete);
					message += msg;
			//	if( null != message)
			//		break;
		  }
		}
		return message;
	}
	
	def getInfoOnServer(server : UFServer, tuple : String, delete : Boolean) : String ={
		var serverWriter : DataOutputStream = null;
		var serverReader : DataInputStream = null;
		var message = "";
		var socket : Socket = null;
		try {
			socket = new Socket(server.getHost(), server.getPort()); //connecting to other servers
			serverReader = new DataInputStream(socket.getInputStream());
			serverWriter = new DataOutputStream(socket.getOutputStream());
			//System.out.println("getinfo");
			serverWriter.writeUTF(defaultServerUserName + "," + defaultServerPassword);
			var serverResponse = serverReader.readUTF();
			
			if(Integer.parseInt(serverResponse) == 1)
		  {
		     var newClusterHeadInfo : String = serverReader.readUTF();
		     while(!newClusterHeadInfo.equalsIgnoreCase("end"))
		     {
		       addDistributedServerInfo(newClusterHeadInfo);
		       newClusterHeadInfo = serverReader.readUTF();
		     }
		       
		  }
			
			if(delete){
				
				if( null != socket && ! socket.isClosed()){
					
					for( otherServer <- otherDistributedServers){
				
					  println("serverinfo<>" + otherServer.getHost() + "," + otherServer.getPort());
						serverWriter.writeUTF(encrypt("serverinfo<>" + otherServer.getHost() + "," + otherServer.getPort(), sharedKey));					
					}
			
					
					//serverWriter.writeUTF("deleteFromOtherServer<>"+tuple);
					serverWriter.writeUTF(encrypt("deleteFromOtherServer<>"+tuple + "<>" + port, sharedKey));
					var serverResponse: String = serverReader.readUTF();
					message += serverResponse;
				//	if(!serverResponse.contains("NO MATCH"))
				}
				//	message = "MATCH:" + serverResponse;
			} else{
				System.out.println("delete option");
				if( null != socket && ! socket.isClosed()){
					
					for( otherServer <- otherDistributedServers){
						System.out.println("calls");
						println("serverinfo<>" + otherServer.getHost() + "," + otherServer.getPort());
						serverWriter.writeUTF(encrypt("serverinfo<>" + otherServer.getHost() + "," + otherServer.getPort(),sharedKey));					
					}
					
					//serverWriter.writeUTF("matchFromOtherServer<>"+tuple);
					serverWriter.writeUTF(encrypt("matchFromOtherServer<>"+tuple + "<>" + port, sharedKey));
					
			//		var serverResponse1 : String = serverReader.readUTF();
				//	var serverResponse : String = serverReader.readUTF();
					var serverResponse : String = serverReader.readUTF();
					println("serverResponse after sending match to other server: " + serverResponse)
					message += serverResponse;
					//if(!serverResponse.contains("NO MATCH"))
						//message = "MATCH:" + serverResponse;
					
				}
			}
			//serverWriter.writeUTF("exit<>");
			serverWriter.writeUTF(encrypt("exit<>",sharedKey));
			socket.close();
		} catch {
		  case e : UnknownHostException => System.err.println(e.getMessage()); 
		  case ex: IOException => System.err.println(ex.getMessage()); 
			
		} 
		return message;
	}
	
	def generateStringFromTuple(tuple : Tuple) : String = {
	  
	  var tupleElements = tuple.getTupleElement()
		//List<TupleElement> tupleElements = tuple.getTupleElement();
	  
	  
	  
		var buffer = new StringBuffer();
	  
		var size = tupleElements.size();
		
		
				
		//for(int i = 0; i < size; i++){
		for(i <- 0 until size){
			var tupleElement = tupleElements.get(i);
			if(i>0)
				buffer.append(",");
			buffer.append(tupleElement.getValue());
		}
		return buffer.toString();
	}
	
	def getIndexForMatch (tupleToMatch : Tuple) : Array[Int] = {
		var size = tuples.size();
		
		var matchedIndexes = new Array[Int](size);
		//int[] matchedIndexes = new int[size];
		
		//int matchedIndexes[];
		var count = 0;
		var i = 0;
		//System.out.println("m");
		for(i <- 0 until size){
			
			 if(tuples.get(i).matchTuple(tupleToMatch))
			 {
				 matchedIndexes(count) = i;
				 count += 1;
				// System.out.println("hello " + i + "mvalue : " + matchedIndexes(count-1));
				 
			 }						 
		}
		//println("b/w i = " + i)
		for(i <- count until size)
			matchedIndexes(i) = -1;

	//	println("matchedIndex[0]", matchedIndexes(0));
		//println("matchedIndex[0]", matchedIndexes(1));
		
		//return -1;
		return matchedIndexes;
	}
	
	
	
		
/*	private class ServerToServerComm implements Runnable{
		private UFServer server = null;
		private String tuple;
		public ServerToServerComm(UFServer server, String tuple){
			this.server = server;
			this.tuple = tuple;
		}
		
		@Override
		public void run() {
			DataOutputStream serverWriter = null;
			DataInputStream serverReader = null;
			try {
				Socket socket = new Socket(this.server.getHost(), this.server.getPort());
				serverReader = new DataInputStream(socket.getInputStream());
				serverWriter = new DataOutputStream(socket.getOutputStream());
			} catch (UnknownHostException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			} catch (IOException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
			
		}
		
	}
	*/
	
	
	//encryption-decryption code
	
		 /**
	* Encrypts a string according to the key.
	*/
	def encrypt(str : String, key : String) : String ={
	var result : String = "";
	
	var size = str.length()
	for(i <- 0 until size)
	
	 {
	var ch = encryptCharacter(str.charAt(i), key);
	result += ch;
	}
	return result;
	}
	/**
	* Encrypts a single character according to the ke
	y.
	*/
	def encryptCharacter(ch : Char, key : String) : Char = 
	{
	  var ch2 = ch
	if (Character.isLetter(ch)) {
		if(Character.isUpperCase(ch))
			ch2 = key.charAt(ch2 - 'A');
		else
			ch2 = Character.toLowerCase( key.charAt(ch2 - 'a'));	

	}
	return ch2;
	}
	/**
	* Decrypts a string according to the key.
	*/
	def  decrypt(str : String, key : String) : String = {
	var result = "";
	var size = str.length()
	//println("till here")
	for(i <- 0 until size) 
	{
	  //println("not here")
	var ch = decryptCharacter(str.charAt(i), key);
	result += ch;
	}
	return result;
	}
	/**
	* Decrypts a single character according to the ke
	y.
	*/
	def decryptCharacter(ch : Char, key : String) : Char =
	{
	  var ch2 = ch
	var index = key.indexOf(Character.toUpperCase(ch));
	if (Character.isLetter(ch)) {
		if(Character.isUpperCase(ch))
	    ch2 = ('A' + index).toChar;
		else
		ch2 = ('a' + index).toChar;
	}
	return ch2;
	} 

	
	
	def childInfo (parentInfoName : String, parentInfoPort : Int) : String =
	{
	  var parentInfo = new UFServer(parentInfoName,parentInfoPort)
	  childList.add(parentInfo);
	  	  
	  
	  return "";
	  
	  
	  
	}
	
	
	
//encryption decryption code ends	
	
	
	
	class ClientHandler(clientSocket1 : Socket) extends Runnable {
		//var clientSocket : Socket;
		var reader : DataInputStream = null;
		var writer : DataOutputStream = null;
		
		
		//this(clientSocket : Socket){
			//this.clientSocket = clientSocket;
		var clientSocket : Socket = clientSocket1;
			reader = new DataInputStream(clientSocket.getInputStream());
			writer = new DataOutputStream(clientSocket.getOutputStream());
		//}
		
		@Override
		def run() : Unit =  {
			
			var flag = true;
			
			
			var breakFlag = true
			
			while(breakFlag){
				try {
					var message : String = null;

					var flag1 = true		
					var cipherText : String = reader.readUTF();//getting request from client/server
					
					//decrypting the request
					println("before decrypt: " + cipherText)
					var request = decrypt(cipherText, sharedKey);
					println("after decrypt: " + request)
					//decrypting the request ends
					System.out.println("Request from client-" + clientSocket.getInetAddress().getCanonicalHostName() + "/" + 
					clientSocket.getPort() + ", request -" + request);
					
					requestfromserver.host1 = clientSocket.getInetAddress().getCanonicalHostName()
					//requestfromserver.port1=clientSocket.getPort();
					
					var parts = request.split("<>");
					
					var operation = parts(0)
					//String operation = parts[0];
					if(parts.length == 2 && parts(1).split(",").length >10){
						writer.writeUTF("Invalid Request, Tuple can not have more than 10 elements");
						//continue;
						flag1 = false
					}
					
					
					if(flag1 == true)
					{
						if("serverInfo".equalsIgnoreCase(operation)){
							if(parts(1).split(",").length != 2){
								message = "Invalid Request, Server info can not have more than 2 elements";
						} else{	
							//System.out.println("Hi-1");
								addDistributedServerInfo(parts(1));
								flag1 = false;
							}
						}
						
						else if ("child".equalsIgnoreCase(operation))
						  message = childInfo(clientSocket.getInetAddress().getCanonicalHostName(), Integer.parseInt(parts(1)));
						
						else if("insert".equalsIgnoreCase(operation))
							message = insert(parts(1), true);
						else if("delete".equalsIgnoreCase(operation))
							message = delete(parts(1),requestfromserver);
						else if("deleteFromOtherServer".equalsIgnoreCase(operation))
						{
						  requestfromserver.port1 = Integer.parseInt(parts(2));
						  message = deleteFromOtherServer(parts(1));
						}
							
						else if("match".equalsIgnoreCase(operation))
							message = matchTup(parts(1),requestfromserver);
						else if("matchFromOtherServer".equalsIgnoreCase(operation))
						{
						  requestfromserver.port1 = Integer.parseInt(parts(2));
						  message = matchFromOtherServer(parts(1));
						}
							
						else if("printAllTuples".equalsIgnoreCase(operation))
							message = printAllTuples();
						else if("createnewuser".equalsIgnoreCase(operation))
							message = createnewuser(parts(1));
						else if("deleteuser".equalsIgnoreCase(operation))
							message = deleteuser(parts(1));
						else if("changepassword".equalsIgnoreCase(operation))
							message = changepassword(parts(1));
						else if("exit".equalsIgnoreCase(operation))
							breakFlag = false
						else if("closeserver".equalsIgnoreCase(operation))
						{
							closeFlag = false;
							flag = false;
							breakFlag = false
						}
						if(breakFlag && flag1)
						{	  if(message == null)
							message = "";
						println("sending message: " + message);
						writer.flush();
						writer.writeUTF(message);
						println("sending message success: " + message);
						}
					}
				} catch{
				  case e : IllegalArgumentException =>
					System.err.println(e.getMessage());
					e.printStackTrace();
				  case e: IOException =>
					try {
						writer.writeUTF("I/O error occurs: "+ e.getMessage());
					} catch {
					  case e1 : IOException =>
						System.err.println("Unable to write data to client " + clientSocket.getInetAddress().getCanonicalHostName());
						breakFlag = false
					}
					System.err.println(e.getMessage());
					e.printStackTrace();
					//break;
					breakFlag = false
				} 
			}
			
			exitCleanly();
			if(!flag) System.exit(0);
			
		}
		
		def exitCleanly() : Unit ={
			try {
				writer.close();
				reader.close();
			} catch  {
			  case e : IOException =>
				e.printStackTrace();
			}
		}

	}
}


object serverrun {
  def main(args: Array[String]): Unit = {
  val act = new UFServiceStartPoint
  act.startService();
  }
       }