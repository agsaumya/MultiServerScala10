package com.mohnish.ufclient.multithreaded;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import java.util.regex.Pattern;
import java.lang._
import scala.collection.JavaConversions._



 class UFClientForMultiThreaded {
	
		var  otherDistributedServers =new ArrayList[UFServer]()
	
		private var reader: BufferedReader  = new BufferedReader(new InputStreamReader(System.in))
		private var  currSocket:Socket = null

		private var serverWriter:DataOutputStream  = null
		private var serverReader:DataInputStream  = null
		private var activeServers  = new HashMap[Int,UFServerInfo]()
		
var key :String = "QWERTYUIOPASDFGHJKLZXCVBNM"

	
		
		
		private def getIPAddress( fqdn:String):String = {
		  try{
			return InetAddress.getByName(fqdn).getHostAddress();
		  }
		
		    catch{
		 case e: UnknownHostException=> 
		   println("cannot found host");
		   return (null);
		   }
		}
		
		
		/*
		public static void main(String[] args){
			UFClientForMultiThreaded client = new UFClientForMultiThreaded();
			client.startClient();
			
		}
		*/
	
		
		
		private def exit():Unit={ 
		  try{
			var keys = activeServers.keySet();
			var it =keys.iterator();
			while(it.hasNext()){
				var server = activeServers.get(it.next());
				server.getSocket().close();
			}
		  }
		  catch {
		case e: IOException =>
		println("cannot exit ");
		  		}
		}
		
		
		private def  deleteTuple():Unit = {
		  try{
			if( getParticularSocket()){
				
				//sending other distributed server infos
				 var message:String = null;
				for(  otherServer <- otherDistributedServers){				
					serverWriter.writeUTF(encrypt( "serverinfo<>" + otherServer.getHost() + "," + otherServer.getPort(),key));					
				}
				
				System.out.println("Enter the tuple (containing comma seperated elements) to delete");
				var tupleToDelete = reader.readLine();
				
				serverWriter.writeUTF(encrypt("delete<>"+tupleToDelete,key));
				var serverResponse = serverReader.readUTF();
				if(serverResponse.equalsIgnoreCase(""))
					System.out.println("NO MATCH");
				else 
					System.out.println("MATCH:" + serverResponse);
			}
		  }
		  catch 
		  {case e: IOException =>
		    
		  }
		}
		
		 def startClient():Unit ={
			System.out.println("Welcome to UF Client, Select any one of the following options");
			System.out.println("1. Connect to server");
			System.out.println("2. Disconnect from server");
			System.out.println("3. Insert a Tuple");
			System.out.println("4. Match a Tuple");
			System.out.println("5. Delete a Tuple");
			System.out.println("6. add a new user");
			System.out.println("7. delete an existing user");
			System.out.println("8. change your password");
			System.out.println("9. Print all Tuple");
			System.out.println("10. Close Server"); //previously exit all
			System.out.println("11. Close Client"); //previously exit all
			var flag:Boolean = true;
			while(flag){
				System.out.println("Enter your option");
				
				var option:Int = 0;
				try {
					option = Integer.parseInt(reader.readLine());
					if(option == 1)
						connect();
					else if(option == 2)
						disconnect();
					else if(option == 3)
						insertTuple();
					else if(option == 4)
						matchTuple();
					else if(option == 5)
						deleteTuple();
					else if(option == 6)
						createnewuser();
						else if(option == 7)
						deleteuser();
						else if(option == 8)
						changepassword();
					else if(option == 9)
						printAllTuple();
					else 
						if(option == 10)
						{
							closeserver();
														
						}
						else 
							if(option == 11)	
							{
								disconnectall();
								flag=false;
							}
					/*	if(option == 7)1
					{
						//disconnect();
						if(currSocket !=null)
						currSocket.close();
						
						break;
					}*/
					else
						System.out.println("Incorrect option, try again");
				} catch{
				  case e: ConnectException=>
					println("Server is busy, Try to connect it later");
				
				  case e: UnknownHostException=>
					println("Unable to connect to server, IP address does not exist. Try again");
				  case e: NumberFormatException =>
		            println("Wrong identifier ... please enter again ");	            
				  case  e: IOException=>
					println(e.getMessage());
					//e.printStackTrace();
				} 
			}
			try {
				exit();
			} catch  {
			  case e: IOException=>
				System.err.println("Error closing the socket");
				e.printStackTrace();
			}
		}
	
		
		
		
		
		private def insertTuple():Unit= {
		  try{
			if( getParticularSocket()){
				
				//sending other distributed server infos
				var message = null;
				for(  otherServer <- otherDistributedServers){				
					serverWriter.writeUTF(encrypt("serverinfo<>" + otherServer.getHost() + "," + otherServer.getPort(),key));					
				}
				
			
				
				
				System.out.println("Enter the tuple (containing comma seperated elements) to insert");
				var tuple = reader.readLine();
				serverWriter.writeUTF( encrypt("insert<>" + tuple,key ));
				var serverResponse = serverReader.readUTF();
				System.out.println(serverResponse);
			} 
		  }
		  catch{
		    case e:IOException=>
		      println("cannot insert");
		  }
		}
		
		private def matchTuple() :Unit ={
		  try{
			if( getParticularSocket()){
				
				//sending other distributed server infos
				 var message:String = null;
				for(  otherServer <- otherDistributedServers){				
					serverWriter.writeUTF(encrypt("serverinfo<>" + otherServer.getHost() + "," + otherServer.getPort(),key));					
				}
				
				System.out.println("Enter the tuple (containing comma seperated elements) to match");
				var tupleToMatch = reader.readLine();
				serverWriter.writeUTF(encrypt("match<>"+tupleToMatch,key));
				var  serverResponse = serverReader.readUTF();
				if(serverResponse.equalsIgnoreCase(""))
					println("NO MATCH");
				else 
					System.out.println("MATCH:" + "\n" + serverResponse);
			}
		  }
		  catch {
		    case e:IOException=>
		      println("error in match tuple");
		    
		  }
		}
		
		private  def printAllTuple():Unit= {
		  try{
			if(getParticularSocket()) 
				{
				serverWriter.writeUTF(encrypt("printAllTuples<>",key));
				var serverResponse = serverReader.readUTF();
				println(serverResponse);
				}
		  }
		  catch 
		  {
		    case e:IOException=>
		      println("cannot print all tuples");
		      }
			
			
		}
		private def connect():Unit ={
								
			try
			{
			
				System.out.println("Enter the unique identifier (used for reference to a particular server), server address and port number in seperate lines");
				var id = Integer.parseInt(reader.readLine());
				if( activeServers.containsKey(id)){
					System.out.println("unique identifier "+ id + " already exists, connect fail");
					return;
				}
				var address = reader.readLine();
				var portNum = Integer.parseInt(reader.readLine());
				if(address.contains("www"))
					address = getIPAddress(address);
				
				currSocket = new Socket(address, portNum);							
				
				var authentication:Integer=0
				  	var tempserverreader = new DataInputStream(currSocket.getInputStream())
				  	var tempserverwriter = new DataOutputStream(currSocket.getOutputStream())
				if(currSocket != null)
				{
				  println("enter username");
				  
				  	var username = reader.readLine();

				    println("enter password");
				  	var password = reader.readLine();

				  	tempserverwriter.writeUTF(username+","+password);
				  	var  serverResponse = tempserverreader.readUTF();
				  	if(serverResponse.equalsIgnoreCase("1"))
				  	{	println("entered username and password match");
  
				  	authentication =1
				  	}
				  	else 
				  	{
				  	  println("entered username and password doesnot match")
				  	  authentication =0}
				}
				if(authentication ==1)
					{
				  
				  
				 var newClusterHeadInfo : String = tempserverreader.readUTF();
				
				 while(!newClusterHeadInfo.equalsIgnoreCase("end"))
				{
				   println("adding server");
			addDistributedServerInfo(newClusterHeadInfo);
			newClusterHeadInfo = tempserverreader.readUTF();
				}
				  
				  
				  
					System.out.println("Connected to server : " + id );
					
				//	var ufServer = new UFServer(address, portNum);
					
				//	otherDistributedServers.add(ufServer);
					
				/*if( activeServers.containsKey(id)){
					System.out.println("unique identifier "+ id + " already exists, connect fail");
				//	return;
				}*/
				activeServers.put(id, new UFServerInfo(currSocket));
					}
			}
			catch  {
			  case e: NumberFormatException=>
			    println("Wrong identifier ... please enter options again ");	            
	        
			case e: IOException=>
	            //System.out.println("Couldn't get I/O for " + "the connection");
	        	   println("Server cannot be connected - Wrong Ip/port ");
	        }
			//serverWriter = new DataOutputStream(currSocket.getOutputStream());
			//serverReader = new DataInputStream(currSocket.getInputStream());
		}
		
		private def closeserver():Unit={
			var id:Int = 0;
			try
			{
			System.out.println("Enter the unique id for server for which you want to disconnect");
			id = Integer.parseInt(reader.readLine());
			if( !activeServers.containsKey(id)){
				System.err.println("unique identifier "+ id + " does not exist, disconnect fail");
				return;
			}
			}catch  {
			  case e:NumberFormatException=>
	            println("Wrong identifier ... please enter options again ");
	            return;
	        }
			
			currSocket = activeServers.get(id).getSocket();			
			
			serverReader = activeServers.get(id).getInputStream;
			serverWriter = activeServers.get(id).getOutputStream;
			serverWriter.writeUTF(encrypt("closeserver<>",key));
			
			activeServers.remove(id);
			
			System.out.println("Server Socket disconnected");
			cleanOnExit();
			
		}
		
		private def createnewuser() : Unit ={
		  
		  
			var id : Int= 0;
			try
			{
			System.out.println("Enter the unique id for server for which you want to create new user");
			id = Integer.parseInt(reader.readLine());
			if( !activeServers.containsKey(id)){
				System.err.println("unique identifier "+ id + " does not exist, disconnect fail");
				return;
			}
			}catch  {
			  case e: NumberFormatException=>
	            println("Wrong identifier ... please enter options again ");
	            return;
	        }
			
			currSocket = activeServers.get(id).getSocket();			
			
			serverReader = activeServers.get(id).getInputStream();
			serverWriter = activeServers.get(id).getOutputStream();
			
				  println("enter admin username");
				  
				  var username = reader.readLine();

				  println("enter admin password");
				  var password = reader.readLine();
				  
				  println("enter new username");
				  var newusername = reader.readLine();

				  println("enter new password");
				  var newpassword = reader.readLine();
				  	
			serverWriter.writeUTF(encrypt("createnewuser<>"+username+"," + password + ","+newusername+","+newpassword,key))
			var msg = serverReader.readUTF()
			
			System.out.println(msg);
			
		 
		  
		}
		private def deleteuser() : Unit ={		  
			var id : Int= 0;
			try
			{
			System.out.println("Enter the unique id for server for which you want to delete existing user");
			id = Integer.parseInt(reader.readLine());
			if( !activeServers.containsKey(id)){
				System.err.println("unique identifier "+ id + " does not exist, disconnect fail");
				return;
			}
			}catch  {
			  case e: NumberFormatException=>
	            println("Wrong identifier ... please enter options again ");
	            return;
	        }
			
			currSocket = activeServers.get(id).getSocket();			
			
			serverReader = activeServers.get(id).getInputStream();
			serverWriter = activeServers.get(id).getOutputStream();
			
				  println("enter admin username");
				  
				  var username = reader.readLine();

				  println("enter admin password");
				  var password = reader.readLine();
				  
				  println("enter username");
				  var delusername = reader.readLine();

			  	
				  if(username.equalsIgnoreCase(delusername))
				  {
				    println("Same Admin username and other user is not a valid case");
				  }
				  else{
					  serverWriter.writeUTF(encrypt( "deleteuser<>"+username+"," + password + "," + delusername,key))
					  var msg = serverReader.readUTF()
			
			System.out.println(msg);
					  }
		}
		
		private def changepassword() : Unit ={		  
			var id : Int= 0;
			try
			{
			System.out.println("Enter the unique id for server for which you want to change your passowrd");
			id = Integer.parseInt(reader.readLine());
			if( !activeServers.containsKey(id)){
				System.err.println("unique identifier "+ id + " does not exist, disconnect fail");
				return;
			}
			}catch  {
			  case e: NumberFormatException=>
	            println("Wrong identifier ... please enter options again ");
	            return;
	        }
			
			currSocket = activeServers.get(id).getSocket();			
			
			serverReader = activeServers.get(id).getInputStream();
			serverWriter = activeServers.get(id).getOutputStream();
			
				println("enter your username");
				  
				var username = reader.readLine();

				println("enter your current password");
				var oldpassword = reader.readLine();


				println("enter new password");
				var newpassword = reader.readLine();
				  	
				 
				 
				serverWriter.writeUTF(encrypt("changepassword<>"+username+"," + oldpassword + ","+ newpassword,key))
				var msg = serverReader.readUTF()
			
			System.out.println(msg);
		}
		
		private def disconnect() : Unit ={
			
			var id : Int= 0;
			try
			{
			System.out.println("Enter the unique id for server for which you want to disconnect");
			id = Integer.parseInt(reader.readLine());
			if( !activeServers.containsKey(id)){
				System.err.println("unique identifier "+ id + " does not exist, disconnect fail");
				return;
			}
			}catch  {
			  case e: NumberFormatException=>
	            println("Wrong identifier ... please enter options again ");
	            return;
	        }
			
			currSocket = activeServers.get(id).getSocket();			
			
			serverReader = activeServers.get(id).getInputStream();
			serverWriter = activeServers.get(id).getOutputStream();
			serverWriter.writeUTF(encrypt("exit<>",key));
			
			activeServers.remove(id);
			
			System.out.println("Server Socket disconnected");
			
			cleanOnExit();
		}
private def disconnectall() : Unit ={
			
			var id :Int= 0;

			for( entry <- activeServers.entrySet())
			
			{
				id = entry.getKey();
				
				
			
			//for(Iterator i;;)
			//{
				currSocket = activeServers.get(id).getSocket();			
				
				serverReader = activeServers.get(id).getInputStream();
				serverWriter = activeServers.get(id).getOutputStream();
				serverWriter.writeUTF(encrypt("exit<>",key));
				
				cleanOnExit();
				
				activeServers.remove(id);
				
				System.out.println("Server Socket disconnected");
				
				
			}
		}
		
		private def getParticularSocket() :Boolean ={
			
			
			try
			{
			System.out.println("Enter the unique id for server for which you want to perform this operation");
			var id = Integer.parseInt(reader.readLine());
			if( !activeServers.containsKey(id)){
			System.err.println("unique identifier "+ id + " does not exist, operation fail");
			return false;
			}			
			
			currSocket = activeServers.get(id).getSocket();
			serverReader = activeServers.get(id).getInputStream();
			serverWriter = activeServers.get(id).getOutputStream();
			return true;
			}catch  {
			  case e:NumberFormatException=>
	            println("Wrong identifier please enter options again ");
	            return false;
	        }
			//return false;
		}
		private def cleanOnExit() : Unit ={
		  try{
			serverReader.close();
			serverWriter.close();
			currSocket.close();
		  }
		  catch 
		  {
		  case e: IOException =>
		    println("cannot exit cleanly");
		  }
		}
		//encryption-decryption code
       
                /**
       * Encrypts a string according to the key.
       */
       def encrypt(str : String, key : String) : String ={
       var result : String = "";
       
       var size = str.length()
       for(i <- 0 until size)
       
        {
       var ch = encryptCharacter(str.charAt(i), key);
       result += ch;
       }
       return result;
       }
       /**
       * Encrypts a single character according to the ke
       y.
       */
       def encryptCharacter(ch : Char, key : String) : Char =
       {
         var ch2 = ch
       if (Character.isLetter(ch)) {
               if(Character.isUpperCase(ch))
                       ch2 = key.charAt(ch2 - 'A');
               else
                       ch2 = Character.toLowerCase( key.charAt(ch2 - 'a'));        

       }
       return ch2;
       }
       /**
       * Decrypts a string according to the key.
       */
       def  decrypt(str : String, key : String) : String = {
       var result = "";
       var size = str.length()
       for(i <- 0 until size)
       {
       var ch = decryptCharacter(str.charAt(i), key);
       result += ch;
       }
       return result;
       }
       /**
       * Decrypts a single character according to the ke
       y.
       */
       def decryptCharacter(ch : Char, key : String) : Char =
       {
         var ch2 = ch
       var index = key.indexOf(Character.toUpperCase(ch));
       if (Character.isLetter(ch)) {
               if(Character.isUpperCase(ch))
           ch2 = ('A' + index).toChar;
               else
               ch2 = ('a' + index).toChar;
       }
       return ch2;
       }

def addDistributedServerInfo(serverInfo : String) : Unit = {

//var serverParts : Array[String] = serverInfo.split(",")
var serverParts = serverInfo.split(",")

// String serverParts[] = serverInfo.split(",")
var matched : Boolean = true





println("Arraylist size" + otherDistributedServers.size());

//var ufserver : UFServer =
// for loop execution with a collection
//for( ufserver <- otherDistributedServers)



//for( UFServer ufserver : otherDistributedServers)
for( ufserver <- otherDistributedServers)


{
println(" Server: " + ufserver.getHost() + "," + ufserver.getPort());
if(ufserver.getHost().equalsIgnoreCase(serverParts(0)) && ufserver.getPort() == Integer.parseInt(serverParts(1)) )
matched = false;
}

if(matched)
// otherDistributedServers.add(new UFServer(serverParts(0), Integer.parseInt(serverParts(1)))); //new serverinfo added here
{
var newPortNum = Integer.parseInt(serverParts(1))
var newServerHost = serverParts(0)
//var newUF = new UFServer (newServerHost,newPortNum)
otherDistributedServers.add(new UFServer(serverParts(0), newPortNum)); //new serverinfo added here

}
//println("Arraylist size" + otherDistributedServers.size());

}


				
	}
	object clientrun {
	  
	  
   def main(args: Array[String]): Unit = {
   val act = new UFClientForMultiThreaded
   act.startClient();
   }
}
        
