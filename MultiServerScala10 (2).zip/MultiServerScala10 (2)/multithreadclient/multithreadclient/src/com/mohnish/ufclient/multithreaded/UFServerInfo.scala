package com.mohnish.ufclient.multithreaded;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java._
import java.io._
import scala.actors._
import scala.actors.remote._
import scala.actors.remote.RemoteActor._
import Actor._
import scala.throws

 class UFServerInfo(socket1:Socket ) {
	var  socket:Socket = socket1;
	 var inputStream :DataInputStream  = new DataInputStream(socket.getInputStream());;
	 var outputStream:DataOutputStream = new DataOutputStream(socket.getOutputStream());
	

	  

	
	 def getSocket():Socket={
		return this.socket;
	}
	
	def  getInputStream():DataInputStream={
		return this.inputStream;
	}
	
	 def getOutputStream():DataOutputStream={
		return this.outputStream;
	}
	
}
