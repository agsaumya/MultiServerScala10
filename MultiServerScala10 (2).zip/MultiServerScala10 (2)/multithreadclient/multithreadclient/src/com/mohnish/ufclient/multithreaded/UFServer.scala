package com.mohnish.ufclient.multithreaded;

import java._
import java.io._
import scala.actors._
import scala.actors.remote._
import scala.actors.remote.RemoteActor._
import Actor._

 class UFServer ( host1:String,  port1:Int) {
	var  host:String = host1;
	var  port:Int=port1;
	
	
	
	def  getHost() :String= {
		return this.host;
	}
	
	def  getPort():Int = {
		return this.port;
	}
}
